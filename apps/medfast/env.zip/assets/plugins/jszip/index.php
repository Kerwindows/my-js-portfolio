<?php
 header("Location: ../../../../404.html");
 exit();