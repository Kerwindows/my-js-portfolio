<?php  function content($array_var=[]){ 
include PRIVATE_CONTAINERS_PATH ."/".$array_var['directory']; 
}