<?php function forehead($array_var = []){ ?>
<body>
    <div class="main-wrapper">
        <div class="header mb-4" style="position:relative">
            <div class="header-left">
                <a href="/patients" class="logo">
                    <img src="<?php echo base_url() ?>/assets/img/logo.png" width="35" height="35" alt=""> <span>MedFast</span>
                </a>
            </div>
            
        </div>
<?php }