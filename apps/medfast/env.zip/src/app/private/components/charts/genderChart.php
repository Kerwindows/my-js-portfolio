<?php 
function genderChart($array_var = []) { ?>
<div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div id="radial-patients"></div>
                            </div>
                        </div>
</div>
<?php }